films = [["Inside Out", 30000], ["Avengers Endgame", 50000], ["The Wild Robot", 40000], ["Knives Out", 45000], ["Up", 35000]]

for x in films:
    choice = 0
    print(x)

choice = int(input("Masukkan nomor film yang ingin dipilih: ")) 
if choice == 1:
    film = films[0]
elif choice == 2:
    film = films[1]
elif choice == 3:
    film = films[2]
elif choice == 4:
    film = films[3]
elif choice == 5:
    film = films[4]
else:
    print("Film yang dipilih tidak tersedia atau input bukan numerik")

print(film)