class Film:
    def __init__(self, judul, harga):
        self.judul = judul
        self.harga = harga

    def tampilkan(self):
        print(f"{self.judul} - Rp{self.harga}")

class Transaksi:
    def __init__(self, total = 0, ):
        self.total = total

    def tambah(film, jumlah):
        jumlah += film

    def struk(self):
        print(self.total)

Judul = input("Judul film: ")
Harga = int(input("Harga film: "))

film1 = Film(Judul, Harga)
film1.tampilkan()